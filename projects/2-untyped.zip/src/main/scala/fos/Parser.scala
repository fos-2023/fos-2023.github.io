package fos

import scala.util.parsing.combinator.syntactical.StandardTokenParsers
import scala.util.parsing.input._

object Parser extends StandardTokenParsers:
  import lexical.Identifier

  lexical.delimiters ++= List("(", ")", "\\", ".", "=", ",")
  lexical.reserved ++= List("declare", "in")

  def parse(input: String) =
    val tokens = new lexical.Scanner(input)
    phrase(topLevel)(tokens)

  /** topLevel ::= t | 'declare' ident '=' t (',' ident '=' t)* 'in' topLevel
    */
  val topLevel = topLevelEnv(using Map.empty)
  def topLevelEnv(using Map[String, Term]): Parser[Term] = declare | term

  def declare(using Map[String, Term]) =
    ("declare" ~ bindings ~ "in").flatMap { case _ ~ m ~ _ =>
      topLevelEnv(using m)
    }

  def bindings(using m: Map[String, Term]): Parser[Map[String, Term]] = {
    binding.flatMap { bind =>
      val nm = m + bind
      ("," ~> bindings(using nm)) | success(nm)
    } | success(m)
  }
  def binding(using m: Map[String, Term]) = {
    ident ~ "=" ~ term ^^ { case id ~ _ ~ t => (id -> t) }
  }

  /** t ::= x
    *          | '\' x '.' t
    *          | t t
    *          | '(' t ')'
    */
  def term(using Map[String, Term]): Parser[Term] =
    (AbsOrVar ~ rep(AbsOrVar) ^^ { case t1 ~ ts =>
      (t1 :: ts).reduceLeft[Term]((t1, t2) => App(t1, t2))
    }
      | failure("illegal start of term"))

  def AbsOrVar(using m: Map[String, Term]): Parser[Term] =
    (ident ^^ { case chars => m.getOrElse(chars, Var(chars)) }
      | ("\\" ~ ident ~ ".").flatMap { case _ ~ id ~ _ =>
        term(using m.removed(id)).map(Abs(id, _))
      }
      | "(" ~ term ~ ")" ^^ { case _ ~ t ~ _ => t }
      | failure("illegal start of .."))
