package fos

import scala.util.parsing.combinator.syntactical.StandardTokenParsers
import scala.util.parsing.input._

/** This object implements a parser and evaluator for the
 *  simply typed lambda calculus found in Chapter 9 of
 *  the TAPL book.
 */
object SimplyTypedExtended extends  StandardTokenParsers {
  lexical.delimiters ++= List(
    "(", ")", "\\", ".", ":", "=", "->", "{", "}", ",", "*", "+",
    "=>", "|",
    // imperative bundle
    ";", "<", ">", "!", ":=",
    // functional bundle
    "\\/", "/\\", "[", "]",
  )
  lexical.reserved ++= List(
    "Bool", "Nat", "true", "false", "if", "then", "else", "succ",
    "pred", "iszero", "let", "in", "fst", "snd", "fix", "letrec",
    "case", "of", "inl", "inr", "as",
    // imperative bundle
    "Unit", "unit", "Ref", "ref", "loc",
    // functional bundle
    "List", "nil", "cons",
  )

  /** t ::=          "true"
   *               | "false"
   *               | number
   *               | "succ" t
   *               | "pred" t
   *               | "iszero" t
   *               | "if" t "then" t "else" t
   *               | ident
   *               | "\" ident ":" T "." t
   *               | t t
   *               | "(" t ")"
   *               | "let" ident ":" T "=" t "in" t
   *               | "{" t "," t "}"
   *               | "fst" t
   *               | "snd" t
   *               | "inl" t "as" T
   *               | "inr" t "as" T
   *               | "case" t "of" "inl" ident "=>" t "|" "inr" ident "=>" t
   *               | "fix" t
   *               | "letrec" ident ":" T "=" t "in" t
   */

  def parserWithPrefix(separator : String, parser : Parser[Term]): Parser[Term] =
    positioned(
      separator ~ parser ^^ { case _ ~ t => t }
    )

  def term: Parser[Term] =
    positioned(
      assignTerm ~ rep(";" ~> assignTerm) ^^ { case t ~ ts => (t :: ts).reduceLeft[Term](Sequence.apply) }
      | failure("illegal start of term"))

  def assignTerm: Parser[Term] =
    positioned(
      ascriptionTerm ~ rep(":=" ~> ascriptionTerm) ^^ { case t ~ ts => (t :: ts).reduceLeft[Term](Assign.apply) }
    )

  def ascriptionTerm: Parser[Term] = positioned(
    leftBoundTerm ~ rep("as" ~> typ) ^^ { case t ~ tps =>
      tps.foldLeft(t)(Ascription(_, _))
    }
  )

  def leftBoundTerm: Parser[Term] = applicationTerm

  def applicationTerm: Parser[Term] = positioned(
    projTerm ~ rep(appSuffix) ^^ { case t ~ ts =>
      ts.foldLeft(t) { (prev, next) =>
        next match {
          case next: Term => App(prev, next)
          case next: Type => TypeApp(prev, next)
        }
      }
    }
  | failure("illegal start of app term")
  )

  def appSuffix: Parser[Term | Type] =
    "[" ~> typ <~ "]" | projTerm

  def projTerm: Parser[Term] = positioned(
    simpleTerm ~ rep("." ~> intOrLabel) ^^ { case t ~ ts =>
      ts.foldLeft(t)((prev, label) => RecordProj(prev, label))
    }
  )

  def intOrLabel: Parser[String] = (
    ident
  | numericLit ^^ { s => s.toInt.toString }
  )

  def simpleTerm: Parser[Term] =
    positioned(
      "true"          ^^^ True
    | "false"         ^^^ False
    | "unit"          ^^^ UnitVal // Imperative - unit value
    | numericLit      ^^ { case chars => lit2Num(chars.toInt) }
    | "succ" ~ leftBoundTerm   ^^ { case "succ" ~ t => Succ(t) }
    | "pred" ~ leftBoundTerm   ^^ { case "pred" ~ t => Pred(t) }
    | "iszero" ~ leftBoundTerm ^^ { case "iszero" ~ t => IsZero(t) }
    | "ref" ~ leftBoundTerm ^^ { case "ref" ~ t => Ref(t) } // Imperative - reference creation
    | "!" ~ leftBoundTerm ^^ { case "!" ~ t => Deref(t) } // Imperative - reference extract value
    | "if" ~ term ~ "then" ~ leftBoundTerm ~ "else" ~ leftBoundTerm ^^ {
        case "if" ~ t1 ~ "then" ~ t2 ~ "else" ~ t3 =>
          println(s"parsed if with: $t1, $t2, $t3")
          If(t1, t2, t3)
      }
    | ident ^^ { case id => Var(id) }
    | "\\" ~ ident ~ ":" ~ typ ~ "." ~ leftBoundTerm ^^ { case "\\" ~ x ~ ":" ~ tp ~ "." ~ t => Abs(x, tp, t) }
    | "(" ~> term <~ ")"  ^^ { case t => t }
    | "let" ~ ident ~ ":" ~ typ ~ "=" ~ term ~ "in" ~ leftBoundTerm ^^ {
        case "let" ~ id ~ ":" ~ tp ~ "=" ~ t1 ~ "in" ~ t2 => App(Abs(id, tp, t2), t1)
      }
    | "{" ~ term ~ "," ~ term ~ "}" ^^ { case "{" ~ t1 ~ "," ~ t2 ~ "}" => TermPair(t1, t2) }
    | "fst" ~ leftBoundTerm                  ^^ { case "fst" ~ t => First(t) }
    | "snd" ~ leftBoundTerm                  ^^ { case "snd" ~ t => Second(t) }
    | "inl" ~ leftBoundTerm ~ "as" ~ typ    ^^ { case "inl" ~ t ~ "as" ~ tp => Inl(t, tp) }
    | "inr" ~ leftBoundTerm ~ "as" ~ typ    ^^ { case "inr" ~ t ~ "as" ~ tp => Inr(t, tp) }
    | "case" ~ term ~ "of" ~ "inl" ~ ident ~ "=>" ~ leftBoundTerm ~ "|" ~ "inr" ~ ident ~ "=>" ~ leftBoundTerm ^^ {
      case "case" ~ t1 ~ "of" ~ "inl" ~ id1 ~ "=>" ~ t2 ~ "|" ~ "inr" ~ id2 ~ "=>" ~ t3 =>
        Case(t1, id1, t2, id2, t3)
      }
    | "fix" ~ leftBoundTerm ^^ { case "fix" ~ t => Fix(t) }
    | "letrec" ~ ident ~ ":" ~ typ ~ "=" ~ term ~ "in" ~ leftBoundTerm ^^ {
        case "letrec" ~ id ~ ":" ~ tp ~ "=" ~ t1 ~ "in" ~ t2 =>
          App(Abs(id, tp, t2), Fix(Abs(id, tp, t1)))
      }
    | "!" ~> leftBoundTerm ^^ Deref
    | "/\\" ~> (ident <~ ".") ~ simpleTerm ^^{ case x ~ t => TypeAbs(x, t) }
    | "{" ~> rep(pairP(ident, "=", term) <~ ",") <~ "}" ^^ Record
    | "{" ~> rep(term <~ ",") <~ "}" ^^ { values => Record(desugarTuple(values)) }
    | "nil" ~> "[" ~> typ <~ "]" ^^ NilVal
    | ("cons" ~> "[" ~> typ <~ "]") ~ simpleTerm ~ simpleTerm ^^ { case tp ~ t1 ~ t2 => Cons(tp, t1, t2) }
    | "case" ~ term ~ "of" ~ "nil" ~ "=>" ~ leftBoundTerm ~ "|" ~ "cons" ~ ident ~ ident ~ "=>" ~ leftBoundTerm ^^ {
      case "case" ~ t1 ~ "of" ~ "nil" ~ "=>" ~ t2 ~ "|" ~ "cons" ~ id1 ~ id2 ~ "=>" ~ t3 =>
        ListCase(t1, t2, id1, id2, t3)
      }
    | failure("illegal start of simple term")
    )

  /** Type       ::= SimpleType [ "->" Type ]
   */
  def typ: Parser[Type] =
    positioned(
      simpleType ~ opt("->" ~> typ)   ^^ {
        case t1 ~ Some(t2) => TypeFun(t1, t2)
        case t1 ~ None => t1
      }
    | failure("illegal start of type"))

  /** SimpleType ::= BaseType [ ("*" SimpleType) | ("+" SimpleType) ]
   */
  def simpleType: Parser[Type] =
    positioned(
      baseType ~ opt(("*" ~ simpleType) | ("+" ~ simpleType)) ^^ {
        case bt ~ Some("*" ~ st) => TypePair(bt, st)
        case bt ~ Some("+" ~ st) => TypeSum(bt, st)
        case bt ~ None => bt
      }
    | failure("illegal start of simple type"))

  /** BaseType ::= "Bool" | "Nat" | "(" Type ")"
   */
  def baseType: Parser[Type] =
    positioned(
      "Bool" ^^^ TypeBool
    | "Nat"  ^^^ TypeNat
    | "Unit" ^^^ TypeUnit // Imperative - unit
    | "Ref" ~ typ ^^ { case "Ref" ~ t => TypeRef(t) }
    | typeVarP
    | ("\\/" ~> typeVarP <~ ".") ~ baseType ^^ { case tv ~ tpe => TypeUniversal(tv, tpe) }
    | "{" ~> rep(pairP(ident, ":", typ) <~ ",") <~ "}" ^^ TypeRecord
    | "{" ~> rep(typ <~ ",") <~ "}" ^^ { types => TypeRecord(desugarTuple(types)) }
    | "List" ~> baseType ^^ TypeList
    | "(" ~> typ <~ ")" ^^ { case t => t })

  def typeVarP: Parser[TypeVar] = positioned(
    ident ^^ TypeVar
  )

  def lit2Num(n: Int): Term =
    if (n == 0) Zero else Succ(lit2Num(n - 1))

  def pairP[A, B](p1: => Parser[A], sep: => Parser[?], p2: => Parser[B]): Parser[(A, B)] =
    (p1 <~ sep) ~ p2 ^^ { case l ~ r => (l, r) }

  def desugarTuple[A](values: List[A]): List[(String, A)] =
    values.zipWithIndex.map((v, i) => ((i + 1).toString(), v))



  /** Call by value reducer with a store. */
  def reduce(t: Term, store: Store): (Term, Store) = {
    /* If you implement the imperative bundle, implement this method instead
     * of `reduce(t: Term): Term` below.
     * The default implementation is to always ignore the store.
     */
    (reduce(t), store)
  }

  /** Call by value reducer. */
  def reduce(t: Term): Term =
    ???

  /** Thrown when no reduction rule applies to the given term. */
  case class NoRuleApplies(t: Term) extends Exception(t.toString)

  /** Print an error message, together with the position where it occured. */
  case class TypeError(t: Term, msg: String) extends Exception(msg) {
    override def toString = msg + "\n" + t
  }

  /** The context is a list of variable names paired with their type. */
  final class Context(val termVars: List[(String, Type)], val typeVars: List[String]) {
    def addTerm(x: String, tp: Type): Context =
      Context((x, tp) :: termVars, typeVars)

    def addType(x: String): Context =
      Context(termVars, x :: typeVars)
  }

  object Context {
    val empty: Context = Context(Nil, Nil)
  }


  def typeof(empty: Nil.type, t: Term): Type =
    typeof(Context.empty, t)

  /** Returns the type of the given term <code>t</code>.
   *
   *  @param ctx the initial context
   *  @param t   the given term
   *  @return    the computed type
   */
  def typeof(ctx: Context, t: Term): Type =
    ???

  /** Returns a stream of terms, each being one step of reduction.
   *
   *  @param t      the initial term
   *  @param reduce the evaluation strategy used for reduction.
   *  @return       the stream of terms representing the big reduction.
   */
  def path(t: Term, reduce: Term => Term): LazyList[Term] =
    try {
      var t1 = reduce(t)
      LazyList.cons(t, path(t1, reduce))
    } catch {
      case NoRuleApplies(_) =>
        LazyList.cons(t, LazyList.empty)
    }

  def main(args: Array[String]): Unit = {
    val stdin = new java.io.BufferedReader(new java.io.InputStreamReader(System.in))
    val tokens = new lexical.Scanner(stdin.readLine())
    phrase(term)(tokens) match {
      case Success(trees, _) =>
        try {
          println("parsed: " + trees)
          println("typed: " + typeof(Context.empty, trees))
          var store = Store.empty
          def red(tm: Term): Term = {
            val (ret, store2) = reduce(tm, store)
            store = store2
            ret
          }
          for (t <- path(trees, red)) {
            println(t)
          }
        } catch {
          case tperror: Exception => println(tperror.toString)
        }
      case e =>
        println(e)
    }
  }
}
