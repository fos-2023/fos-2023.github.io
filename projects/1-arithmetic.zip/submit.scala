#!/usr/bin/env -S scala-cli shebang -S 3

// Check out scala toolkit, they're awesome!
//> using toolkit latest

import upickle.default._

val submitURL = "https://adapted-asp-shortly.ngrok-free.app/"

/** Build information */
case class Build(graded: Boolean, files: List[String], submission: List[String]) derives ReadWriter

val build = read[Build](os.read(os.pwd / os.RelPath("./build.json")))

def makeZip(path: os.Path) =
  import java.io._
  import java.util.zip._
  import java.nio.file.Files
  val fileStream = FileOutputStream(path.toString)
  val zipStream = ZipOutputStream(fileStream)

  build.submission.map(os.FilePath(_)).foreach { f =>
    val zipEntry = ZipEntry(f.toString)
    zipStream.putNextEntry(zipEntry)
    Files.copy(f.toNIO, zipStream)
  }

  zipStream.close()
  fileStream.close()

@main def Submit(filepaths : String*) =
  val filepath = filepaths.headOption.getOrElse("./submit.zip")
  println("The following files are going to be zipped: ")
  build.submission.foreach { f => println(" > " + f.toString) }
  val path =
    os.FilePath(filepath).match
      case t: os.Path => t
      case t: os.RelPath => os.pwd / t
      case t: os.SubPath => os.pwd / t
  makeZip(path)
  println(s"Success! Please submit the following file to the form at $submitURL\n$path")
