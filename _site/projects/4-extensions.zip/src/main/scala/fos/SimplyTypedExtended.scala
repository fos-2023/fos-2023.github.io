package fos

import scala.util.parsing.combinator.syntactical.StandardTokenParsers
import scala.util.parsing.input._

/** This object implements a parser and evaluator for the
 *  simply typed lambda calculus found in Chapter 9 of
 *  the TAPL book.
 */
object SimplyTypedExtended extends  StandardTokenParsers {
  lexical.delimiters ++= List(
    "(", ")", "\\", ".", ":", "=", "->", "{", "}", ",", "*", "+",
    "=>", "|",
    // imperative bundle
    ";", "<", ">", "!", ":=",
    // functional bundle
    "\\/", "/\\", "[", "]",
  )
  lexical.reserved ++= List(
    "Bool", "Nat", "true", "false", "if", "then", "else", "succ",
    "pred", "iszero", "let", "in", "fst", "snd", "fix", "letrec",
    "case", "of", "inl", "inr", "as",
    // imperative bundle
    "Unit", "unit", "Ref", "ref", "loc",
    // functional bundle
    "List", "nil", "cons",
  )

  /** t ::=          "true"
   *               | "false"
   *               | number
   *               | "succ" t
   *               | "pred" t
   *               | "iszero" t
   *               | "if" t "then" t "else" t
   *               | ident
   *               | "\" ident ":" T "." t
   *               | t t
   *               | "(" t ")"
   *               | "let" ident ":" T "=" t "in" t
   *               | "{" t "," t "}"
   *               | "fst" t
   *               | "snd" t
   *               | "inl" t "as" T
   *               | "inr" t "as" T
   *               | "case" t "of" "inl" ident "=>" t "|" "inr" ident "=>" t
   *               | "fix" t
   *               | "letrec" ident ":" T "=" t "in" t
   */

  def parserWithPrefix(separator : String, parser : Parser[Term]): Parser[Term] =
    positioned(
      separator ~ parser ^^ { case _ ~ t => t }
    )

  def term: Parser[Term] =
    ???



  /** Call by value reducer with a store. */
  def reduce(t: Term, store: Store): (Term, Store) = {
    /* If you implement the imperative bundle, implement this method instead
     * of `reduce(t: Term): Term` below.
     * The default implementation is to always ignore the store.
     */
    (reduce(t), store)
  }

  /** Call by value reducer. */
  def reduce(t: Term): Term =
    ???

  /** Thrown when no reduction rule applies to the given term. */
  case class NoRuleApplies(t: Term) extends Exception(t.toString)

  /** Print an error message, together with the position where it occured. */
  case class TypeError(t: Term, msg: String) extends Exception(msg) {
    override def toString = msg + "\n" + t
  }

  /** The context is a list of variable names paired with their type. */
  final class Context(val termVars: List[(String, Type)], val typeVars: List[String]) {
    def addTerm(x: String, tp: Type): Context =
      Context((x, tp) :: termVars, typeVars)

    def addType(x: String): Context =
      Context(termVars, x :: typeVars)
  }

  object Context {
    val empty: Context = Context(Nil, Nil)
  }


  def typeof(empty: Nil.type, t: Term): Type =
    typeof(Context.empty, t)

  /** Returns the type of the given term <code>t</code>.
   *
   *  @param ctx the initial context
   *  @param t   the given term
   *  @return    the computed type
   */
  def typeof(ctx: Context, t: Term): Type =
    ???

  /** Returns a stream of terms, each being one step of reduction.
   *
   *  @param t      the initial term
   *  @param reduce the evaluation strategy used for reduction.
   *  @return       the stream of terms representing the big reduction.
   */
  def path(t: Term, reduce: Term => Term): LazyList[Term] =
    try {
      var t1 = reduce(t)
      LazyList.cons(t, path(t1, reduce))
    } catch {
      case NoRuleApplies(_) =>
        LazyList.cons(t, LazyList.empty)
    }

  def main(args: Array[String]): Unit = {
    val stdin = new java.io.BufferedReader(new java.io.InputStreamReader(System.in))
    val tokens = new lexical.Scanner(stdin.readLine())
    phrase(term)(tokens) match {
      case Success(trees, _) =>
        try {
          println("parsed: " + trees)
          println("typed: " + typeof(Context.empty, trees))
          var store = Store.empty
          def red(tm: Term): Term = {
            val (ret, store2) = reduce(tm, store)
            store = store2
            ret
          }
          for (t <- path(trees, red)) {
            println(t)
          }
        } catch {
          case tperror: Exception => println(tperror.toString)
        }
      case e =>
        println(e)
    }
  }
}
