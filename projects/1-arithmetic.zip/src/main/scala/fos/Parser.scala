package fos

import scala.util.parsing.combinator.syntactical.StandardTokenParsers
import scala.util.parsing.input._

object Parser extends StandardTokenParsers:
  def parse(input: String) =
    val tokens = new lexical.Scanner(input)
    phrase(term)(tokens)

  lexical.reserved ++= List(
    "true",
    "false",
    "if",
    "then",
    "else",
    "succ",
    "pred",
    "declare",
    "in",
    "iszero"
  )

  lexical.delimiters ++= List("=", ",", "(", ")")

  import lexical.NumericLit

  /** term ::= 'true'
    * \| 'false'
    * \| 'if' term 'then' term 'else' term
    * \| numericLit
    * \| 'succ' term
    * \| 'pred' term
    * \| 'iszero' term
    * \| 'declare' ident '=' term (',' ident '=' term)* 'in' term
    */
  def term: Parser[Term] = termEnv(using Map.empty)

  def termEnv(using m: Map[String, Term]): Parser[Term] =
    ("true" ^^^ True
      | "false" ^^^ False
      | "if" ~ termEnv ~ "then" ~ termEnv ~ "else" ~ termEnv ^^ {
        case "if" ~ e1 ~ "then" ~ e2 ~ "else" ~ e3 => If(e1, e2, e3)
      }
      | numericLit ^^ { case chars => lit2Num(chars.toInt) }
      | "succ" ~> termEnv ^^ { case e1 => Succ(e1) }
      | "pred" ~> termEnv ^^ { case e1 => Pred(e1) }
      | "iszero" ~> termEnv ^^ { case e1 => IsZero(e1) }
      | ("declare" ~ bindings ~ "in").flatMap { case _ ~ bindings ~ _ => termEnv(using bindings) }
      | ident.flatMap { s => m.get(s).match {
          case Some(term) => success(term)
          case None => failure(s"ident `$s` is not defined")
        } }
      | "(" ~ termEnv ~ ")" ^^ { case _ ~ term ~ _ => term }
      | failure("illegal start of expression"))

  def bindings(using m: Map[String, Term]): Parser[Map[String, Term]] =
    def nonEmpty(using m: Map[String, Term]): Parser[Map[String, Term]] =
      binding.flatMap { binding =>
        val mNew = m + binding
        ("," ~> nonEmpty(using mNew)) | success(mNew)
      }
    nonEmpty | success(m)

  def binding(using m: Map[String, Term]): Parser[(String, Term)] =
    ident ~ "=" ~ termEnv ^^ { case ident ~ "=" ~ term => (ident, term) }

  def lit2Num(n: Int): Term = if (n == 0) Zero else Succ(lit2Num(n - 1))
