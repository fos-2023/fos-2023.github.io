package fos

import scala.util.parsing.combinator.syntactical.StandardTokenParsers
import scala.util.parsing.input._

object Parser extends StandardTokenParsers {
  lexical.delimiters ++= List("(", ")", "\\", ".", ":", "=", "->", "{", "}", ",", "*")
  lexical.reserved   ++= List("Bool", "Nat", "true", "false", "if", "then", "else", "succ",
                              "pred", "iszero", "let", "in", "fst", "snd")

  def parse(input: String) =
    val tokens = new lexical.Scanner(input)
    phrase(term)(tokens)
    /** t ::=          "true"
   *               | "false"
   *               | number
   *               | "succ" t
   *               | "pred" t
   *               | "iszero" t
   *               | "if" t "then" t "else" t
   *               | ident
   *               | "\" ident ":" T "." t
   *               | t t
   *               | "(" t ")"
   *               | "let" ident ":" T "=" t "in" t
   *               | "{" t "," t "}"
   *               | "fst" t
   *               | "snd" t
   */
  def term: Parser[Term] =
    positioned(
      simpleTerm ~ rep(simpleTerm)    ^^ { case t ~ ts => (t :: ts).reduceLeft[Term](App.apply) }
      | failure("illegal start of term"))

  def simpleTerm: Parser[Term] = positioned(
      "true"          ^^^ True
    | "false"         ^^^ False
    | numericLit      ^^ { case chars => lit2Num(chars.toInt) }
    | "succ" ~ term   ^^ { case "succ" ~ t => Succ(t) }
    | "pred" ~ term   ^^ { case "pred" ~ t => Pred(t) }
    | "iszero" ~ term ^^ { case "iszero" ~ t => IsZero(t) }
    | "if" ~ term ~ "then" ~ term ~ "else" ~ term ^^ {
        case "if" ~ t1 ~ "then" ~ t2 ~ "else" ~ t3 => If(t1, t2, t3)
      }
    | ident ^^ { case id => Var(id) }
    | "\\" ~ ident ~ ":" ~ typ ~ "." ~ term ^^ { case "\\" ~ x ~ ":" ~ tp ~ "." ~ t => Abs(x, tp, t) }
    | "(" ~> term <~ ")"  ^^ { case t => t }
    | "let" ~ ident ~ ":" ~ typ ~ "=" ~ term ~ "in" ~ term ^^ {
        case "let" ~ id ~ ":" ~ tp ~ "=" ~ t1 ~ "in" ~ t2 => Let(id, tp, t1, t2)
      }
    | "{" ~ term ~ "," ~ term ~ "}" ^^ { case "{" ~ t1 ~ "," ~ t2 ~ "}" => TermPair(t1, t2) }
    | "fst" ~ term                  ^^ { case "fst" ~ t => First(t) }
    | "snd" ~ term                  ^^ { case "snd" ~ t => Second(t) }
    | failure("illegal start of simple term"))

  /** T       ::=   "Bool"
   *              | "Nat"
   *              | T "->" T
   *              | "(" T ")"
   *              | singleLetterIdent
   */
  def typ: Parser[Type] =
    positioned(
      simpleType ~ opt("->" ~> typ)   ^^ {
        case t1 ~ Some(t2) => TypeFun(t1, t2)
        case t1 ~ None => t1
      }
    | failure("illegal start of type"))

  def simpleType: Parser[Type] = positioned(
      baseType ~ opt("*" ~ simpleType) ^^ {
        case bt ~ Some("*" ~ st) => TypePair(bt, st)
        case bt ~ None => bt
      }
    | failure("illegal start of simple type"))

  def baseType: Parser[Type] = positioned(
      "Bool" ^^^ TypeBool
    | "Nat"  ^^^ TypeNat
    | "(" ~> typ <~ ")" ^^ { case t => t }
    | singleLetterIdent ^^ (s => TypeUninterpreted(s))
  )

  def singleLetterIdent: Parser[String] =
    elem("single-letter ident", e => e.isInstanceOf[lexical.Identifier] && e.chars.length == 1) ^^ (_.chars)

  def lit2Num(n: Int): Term =
    if (n == 0) Zero else Succ(lit2Num(n - 1))
}
